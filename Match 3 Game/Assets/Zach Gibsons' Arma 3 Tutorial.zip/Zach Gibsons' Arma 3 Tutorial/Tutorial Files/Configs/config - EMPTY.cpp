class CfgPatches
{
 class WEAPON						////Every spot i say Weapon, you must enter the same info ie, alwyas enter "scarh" or "m16a3_mod1"
 {
	requiredaddons[] = {};
	requiredversion = 0.1;
	units[] = {};
	weapons[] = {"WEAPON"};
	magazines[] = {""};				//mags used
 };
};
/*external*/ class Mode_SemiAuto;
/*external*/ class Mode_Burst;

class CfgWeapons {
	class WEAPON_base {
		access = 3;
		afmax = 0;
		aidispersioncoefx = 4;
		aidispersioncoefy = 5;
		airateoffire = 0.5;
		airateoffiredistance = 500;
		ammo = "";
		autofire = 1;
		autoreload = 0;
		backgroundreload = 0;
		ballisticscomputer = 0;
		bullet1[] = {"A3\sounds_f\weapons\shells\7_62\metal_762_01.wav", 0.1, 1, 15};
		bullet10[] = {"A3\sounds_f\weapons\shells\7_62\grass_762_02.wav", 0.01, 1, 15};
		bullet11[] = {"A3\sounds_f\weapons\shells\7_62\grass_762_03.wav", 0.01, 1, 15};
		bullet12[] = {"A3\sounds_f\weapons\shells\7_62\grass_762_04.wav", 0.01, 1, 15};
		bullet2[] = {"A3\sounds_f\weapons\shells\7_62\metal_762_02.wav", 0.1, 1, 15};
		bullet3[] = {"A3\sounds_f\weapons\shells\7_62\metal_762_03.wav", 0.177828, 1, 15};
		bullet4[] = {"A3\sounds_f\weapons\shells\7_62\metal_762_04.wav", 0.177828, 1, 15};
		bullet5[] = {"A3\sounds_f\weapons\shells\7_62\dirt_762_01.wav", 0.1, 1, 15};
		bullet6[] = {"A3\sounds_f\weapons\shells\7_62\dirt_762_02.wav", 0.1, 1, 15};
		bullet7[] = {"A3\sounds_f\weapons\shells\7_62\dirt_762_03.wav", 0.1, 1, 15};
		bullet8[] = {"A3\sounds_f\weapons\shells\7_62\dirt_762_04.wav", 0.1, 1, 15};
		bullet9[] = {"A3\sounds_f\weapons\shells\7_62\grass_762_01.wav", 0.01, 1, 15};
		candrop = 1;
		canlock = 0;
		canshootinwater = 0;
		cartridgepos = "nabojnicestart";
		cartridgevel = "nabojniceend";
		count = 0;
		cursor = "arifle";
		cursoraim = "CursorAim";
		cursoraimon = "";
		cursorsize = 1;
		cmimmunity = 1;
		descriptionshort = "WEAPON <br />Caliber: ";
		detectrange = 0;
		dexterity = 1.64;
		discretedistance[] = {100, 300, 400, 600, 800};
		discretedistanceinitindex = 1;
		dispersion = 0.0001;
		displayname = "WEAPON";
		disposableweapon = 0;
		distancezoommax = 300;
		distancezoommin = 300;
		drysound[] = {"A3\sounds_f\weapons\other\dry7.wav", 0.01, 1};
		emptysound[] = {"", 1, 1};
		enableattack = 1;
		ffcount = 3;
		fffrequency = 11;
		ffmagnitude = 0.5;
		fireanims[] = {};
		firelightduration = 0.05;
		firelightintensity = 0.012;
		firespreadangle = "3.0f";
		flash = "gunfire";
		flashsize = 0.5;
		forceoptics = 0;
		handanim[] = {"OFP2_ManSkeleton","WEAPONFOLDER\anim\handanim_WEAPON.rtm"};	//hand animation lcation
		hiddenselections[] = {};
		hiddenselectionstextures[] = {};
		hiddenunderwaterselections[] = {};
		hiddenunderwaterselectionstextures[] = {};
		htmax = 600;
		htmin = 1;
		initspeed = 0;
		irdistance = 0;
		irdotintensity = 0.001;
		irlaserend = "laser dir";
		irlaserpos = "laser pos";
		laser = 0;
		lockacquire = 1;
		lockedtargetsound[] = {"\A3\sounds_f\dummysound", 0.000316228, 6};
		lockingtargetsound[] = {"\A3\sounds_f\dummysound", 0.000316228, 2};
		magazinereloadtime = 0;
		magazines[] = {""};							//magazines used
		maxleadspeed = 23;
		maxrange = 500;
		maxrangeprobab = 0.04;
		maxrecoilsway = 0.008;
		memorypointcamera = "eye";
		mfact = 1;
		mfmax = 0;
		midrange = 150;
		midrangeprobab = 0.58;
		minrange = 1;
		minrangeprobab = 0.3;
		model = "WEAPON_MAIN_FOLDER\WEAPONP3D";					//weapon location of p3d...(dont add .p3d at the end)
		modelmagazine = "";
		modeloptics = "-";
		modelspecial = "";
		modes[] = {"Single", "Burst"};
		multiplier = 1;
		muzzleend = "konec hlavne";
		muzzlepos = "usti hlavne";
		muzzles[] = {"this"};
		namesound = "rifle";
		optics = 0;
		opticsdisableperipherialvision = 0.67;
		opticsflare = 0;
		opticsid = 0;
		opticsppeffects[] = {};
		opticszoominit = 0.75;
		opticszoommax = 1.1;
		opticszoommin = 0.375;
		picture = "\WEAPON_MAIN_FOLDER\UI\gear_WEAPON_x_ca";
		primary = 10;
		recoil = "assaultRifleBase";
		recoilprone = "assaultRifleBase";
		reloadaction = "GestureReloadMX";							//reload gesture
		reloadmagazinesound[] = {"A3\sounds_f\weapons\reloads\new_trg.wav", 0.1, 1, 30};
		reloadsound[] = {"", 1, 1};
		reloadtime = 0.15;
		scope = 0;
		selectionfireanim = "zasleh";
		showaimcursorinternal = 1;
		showempty = 1;
		shownunderwaterselections[] = {};
		showswitchaction = 0;
		showtoplayer = 1;
		simulation = "Weapon";
		sound[] = {};
		soundbegin[] = {"sound", 1};
		soundbeginwater[] = {"sound", 1};
		soundbullet[] = {"bullet1", 0.083, "bullet2", 0.083, "bullet3", 0.083, "bullet4", 0.083, "bullet5", 0.083, "bullet6", 0.083, "bullet7", 0.083, "bullet8", 0.083, "bullet9", 0.083, "bullet10", 0.083, "bullet11", 0.083, "bullet12", 0.083};
		soundburst = 1;
		soundclosure[] = {"sound", 1};
		soundcontinuous = 0;
		soundend[] = {"sound", 1};
		soundloop[] = {"sound", 1};
		swaydecayspeed = 2;
		tbody = 100;
		texturetype = "default";
		type = 1;
		uipicture = "\A3\weapons_f\data\UI\icon_regular_CA.paa";
		useaction = 0;
		useactiontitle = "";
		useasbinocular = 0;
		usemodeloptics = 1;
		value = 4;
		weaponinfotype = "RscWeaponZeroing";
		weaponlockdelay = 0;
		weaponlocksystem = 0;
		weaponpoolavailable = 1;
		weaponsoundeffect = "";
		weight = 0;
		class Library {
			libtextdesc = "LONG DETAILED WEAPON DESCRIPTION HERE";
		};
		class GunClouds {
			access = 0;
			cloudletaccy = 0;
			cloudletalpha = 0.3;
			cloudletanimperiod = 1;
			cloudletcolor[] = {1, 1, 1, 0};
			cloudletduration = 0.05;
			cloudletfadein = 0;
			cloudletfadeout = 0.1;
			cloudletgrowup = 0.05;
			cloudletmaxyspeed = 100;
			cloudletminyspeed = -100;
			cloudletshape = "cloudletClouds";
			cloudletsize = 1;
			deltat = 0;
			initt = 0;
			interval = -0.02;
			size = 0.3;
			sourcesize = 0.02;
			timetolive = 0;
			class Table {
				class T0 {
					color[] = {1, 1, 1, 0};
					maxt = 0;
				};
			};
		};
		class WeaponSlotsInfo {
			allowedslots[] = {901};
			mass = 4;
			class MuzzleSlot {};
			class CowsSlot {};
			class PointerSlot {};
		};	
		class GunParticles {
			class FirstEffect {
				directionname = "Konec hlavne";
				effectname = "RifleAssaultCloud";
				positionname = "Usti hlavne";
			};
		};
		class Single: Mode_SemiAuto {
			aidispersioncoefx = 1.4;
			aidispersioncoefy = 1.7;
			airateoffire = 2;
			airateoffiredistance = 500;
			artillerycharge = 1;
			artillerydispersion = 1;
			autofire = 0;
			begin1[] = {"A3\sounds_f\weapons\Trg20\trg_single_1.wav", 2.51189, 1, 1200};
			begin2[] = {"A3\sounds_f\weapons\Trg20\trg_single_2.wav", 2.51189, 1, 1200};
			begin3[] = {"A3\sounds_f\weapons\Trg20\trg_single_3.wav", 2.51189, 1, 1200};
			burst = 1;
			canshootinwater = 0;
			closure1[] = {"A3\sounds_f\weapons\closure\closure_rifle_2.wav", 3.16228, 1, 500};
			closure2[] = {"A3\sounds_f\weapons\closure\closure_rifle_3.wav", 3.16228, 1, 500};
			dispersion = 0.00093;
			displayname = "Semi";
			ffcount = 1;
			fffrequency = 11;
			ffmagnitude = 0.5;
			flash = "gunfire";
			flashsize = 0.1;
			maxrange = 500;
			maxrangeprobab = 0.2;
			midrange = 250;
			midrangeprobab = 0.7;
			minrange = 2;
			minrangeprobab = 0.3;
			multiplier = 1;
			recoil = "recoil_single_trg";
			recoilprone = "recoil_single_prone_trg";
			reloadtime = 0.065;
			requiredoptictype = -1;
			showtoplayer = 1;
			sound[] = {"", 10, 1};
			soundbegin[] = {"begin1", 0.333, "begin2", 0.333, "begin3", 0.333};
			soundbeginwater[] = {"sound", 1};
			soundburst = 0;
			soundclosure[] = {"closure1", 0.5, "closure2", 0.5};
			soundcontinuous = 0;
			soundend[] = {};
			soundloop[] = {};
			texturetype = "semi";
			useaction = 0;
			useactiontitle = "";
			weaponsoundeffect = "DefaultRifle";
		};
		class Burst: Mode_Burst {									//okay...so I've had a problem of making it full Auto, for some reason it never works so ill go over it in an update tutorial
			aidispersioncoefx = 2;
			aidispersioncoefy = 3;
			airateoffire = "1e-006";
			airateoffiredistance = 500;
			artillerycharge = 1;
			artillerydispersion = 1;
			autofire = 0;
			begin1[] = {"A3\sounds_f\weapons\Trg20\trg_single_1.wav", 2.51189, 1, 1200};
			begin2[] = {"A3\sounds_f\weapons\Trg20\trg_single_2.wav", 2.51189, 1, 1200};
			begin3[] = {"A3\sounds_f\weapons\Trg20\trg_single_3.wav", 2.51189, 1, 1200};
			burst = 4;										//number of shots fired each trigger pull
			canshootinwater = 0;
			closure1[] = {"A3\sounds_f\weapons\closure\closure_rifle_2.wav", 3.16228, 1, 500};
			closure2[] = {"A3\sounds_f\weapons\closure\closure_rifle_3.wav", 3.16228, 1, 500};
			dispersion = 0.00093;
			displayname = "Burst";
			ffcount = 1;
			fffrequency = 11;
			ffmagnitude = 0.5;
			flash = "gunfire";
			flashsize = 0.1;
			maxrange = 30;
			maxrangeprobab = 0.05;
			midrange = 15;
			midrangeprobab = 0.7;
			minrange = 0;
			minrangeprobab = 0.9;
			multiplier = 1;
			recoil = "recoil_auto_trg";
			recoilprone = "recoil_auto_prone_trg";
			reloadtime = 0.07;
			requiredoptictype = -1;
			showtoplayer = 1;
			sound[] = {"", 10, 1};
			soundbegin[] = {"begin1", 0.333, "begin2", 0.333, "begin3", 0.333};
			soundbeginwater[] = {"sound", 1};
			soundburst = 0;
			soundclosure[] = {"closure1", 0.5, "closure2", 0.5};
			soundcontinuous = 0;
			soundend[] = {"sound", 1};
			soundloop[] = {};
			texturetype = "burst";
			useaction = 0;
			useactiontitle = "";
			weaponsoundeffect = "DefaultRifle";
		};
		
	};
	class WEAPON : WEAPON_base {
		scope = 2;
	};
};

class CfgMagazines {
	/*external*/ class 30Rnd_556x45_Stanag;								//Ill keep all this info here for you
	class tb_30Rnd_556x45_B_Stanag : 30Rnd_556x45_Stanag {
		ammo = "TB_556x45_Ball";
		count = 30;
		descriptionshort = "Caliber: 45 ACP UMP Mag<br />Rounds: 30<br />Used in: HK UMP-45";
		displayname = "45 ACP 30rnd UMP Mag (Ball)";						
		initspeed = 930;			
		lastroundstracer = 0;
		picture = "\tb_arifle_hkump_folded\UI\gear_hkump_mag_ca";				//Mag UI images are 256x256
		model = "tb_arifle_hkump_folded\hkump_mag";						
		scope = 2;
		tracersevery = 0;
	};
	class tb_30Rnd_556x45_T_Stanag : tb_30Rnd_556x45_B_Stanag {
		ammo = "TB_556x45_Tracer";
		descriptionshort = "Caliber: 45 ACP UMP Mag<br />Rounds: 30<br />Used in: HK UMP-45";
		displayname = "45 ACP 30rnd UMP Mag (Tracer)";
		lastroundstracer = 0;
		scope = 2;
		tracersevery = 1;
	};
};
class CfgAmmo {
	/*external*/ class B_556x45_Ball;
	class TB_556x45_Ball : B_556x45_Ball {
		airfriction = -0.001425;
		caliber = 0.5;							//1 = 7.76.......or something like that
		cost = 1;
		deflecting = 20;
		hit = 8;							//damage?
		indirecthit = 0;
		indirecthitrange = 0;
		model = "\A3\Weapons_f\Data\bullettracer\tracer_red";		//keep this
		nvgonly = 1;
		tracerendtime = 1;
		tracerscale = 1;
		tracerstarttime = 0.05;
	};
	class TB_556x45_Tracer : TB_556x45_Ball {
		airfriction = -0.001425;
		caliber = 0.4;
		model = "\A3\Weapons_f\Data\bullettracer\tracer_red";
		nvgonly = 0;
		tracerendtime = 1.4;
		tracerscale = 1;
		tracerstarttime = 0.06;
	};
};		